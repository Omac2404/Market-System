﻿using System.ComponentModel.DataAnnotations;

namespace MVCProje1.Models
{
	public class PasswordDto
	{
		[Required(ErrorMessage = "Simdi kullandiginiz sifreyi giriniz"), MaxLength(100)]
		public string CurrentPassword { get; set; } = "";

		[Required(ErrorMessage = "Yeni sifreyi giriniz"),MaxLength(100)]
		public string NewPassword { get; set; } = "";

		[Required(ErrorMessage = "Dogrualama sifresi giriniz"),]
		[Compare("NewPassword", ErrorMessage = "Dogrulama ile sifre eslesmiyor")]
		public string ConfirmPassword { get; set; } = "";
	}
}
