﻿using System.ComponentModel.DataAnnotations;

namespace MVCProje1.Models
{
	public class RegisterDto
	{
		[Required(ErrorMessage = "Isim alani dolu olmak zorunda"), MaxLength(100)]
		public string FirstName { get; set; } = "";

		[Required(ErrorMessage = "Soyisim alani dolu olmak zorunda"), MaxLength(100)]
		public string LastName { get; set; } = "";

		[Required,EmailAddress , MaxLength(100)]
		public string Email { get; set; } = "";

		[Phone(ErrorMessage = "Telefon numarasi formati gecersiz"), MaxLength(20)]
		public string PhoneNumber { get; set; }

		[Required, MaxLength(200)]
		public string Address { get; set; } = "";

		[Required, MaxLength(100)]
		public string Password { get; set; } = "";

		[Required(ErrorMessage = "Dogrualama sifresi giriniz"),]
		[Compare("Password", ErrorMessage = "Dogrulama ile sifre eslesmiyor")]
		public string ConfirmPassword { get; set; } = "";
	}
}
